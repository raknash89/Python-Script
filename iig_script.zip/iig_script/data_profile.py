#!/usr/bin/env python

from copybook_parser import *


import codecs

EBCDIC2ASCII= list(map( chr, [
    0x00,0x01,0x02,0x03,0xA3,0x09,0x97,0x7F,0xA4,0xA4,0x01,0x0B,0x0C,0x0D,0x0E,0x0F,
    0x10,0x11,0x12,0x16,0xAE,0x15,0x08,0x2D,0x18,0x19,0xA9,0xA9,0x2D,0x2D,0x2D,0x2D,
    0xD0,0x01,0x21,0xA4,0xA6,0x0A,0x17,0x1B,0xA4,0xA4,0x3B,0xA9,0xA4,0x05,0x06,0x07,
    0xA4,0xA4,0x16,0xA4,0xA3,0xBA,0x1F,0x04,0xA4,0xA4,0xA4,0xA9,0x14,0x15,0xA4,0x1A,
    0x20,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA2,0x2E,0x3C,0x28,0x2B,0x2E,
    0x26,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0x21,0x24,0x2A,0x29,0x3B,0xAC,
    0x2D,0x2F,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0x2C,0x25,0x5F,0x9B,0x3F,
    0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0x3A,0x23,0x40,0x27,0x3D,0x22,
    0xA4,0x61,0x62,0x63,0x64,0x65,0x66,0x67,0x68,0x69,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,
    0xA4,0x6A,0x6B,0x6C,0x6D,0x6E,0x6F,0x70,0x71,0x72,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,
    0xA4,0xA4,0x73,0x74,0x75,0x76,0x77,0x78,0x79,0x7A,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,
    0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,0x60,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,
    0x7B,0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,
    0x7D,0x4A,0x4B,0x4C,0x4D,0x4E,0x4F,0x50,0x51,0x52,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,
    0x5C,0xA4,0x53,0x54,0x55,0x56,0x57,0x58,0x59,0x5A,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4,
    0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0xA4,0xA4,0xA4,0xA4,0xA4,0xA4
    ] ))

def E2A_str( string ):
    """Return the ASCII version of this EBCDIC string."""
    #     r= StringIO.StringIO()
    #     for c in string:
    #         r.write( EBCDIC2ASCII[ ord(c) ] )
    #     s= r.getvalue()
    #     r.close()
    #AP changes start
    #chars= [ EBCDIC2ASCII[ ord(c) ] for c in string ]
    chars  = []
    for i in range(len(string)):
        order = ord(string[i:i+1])
        chars.append(EBCDIC2ASCII[order])
    #AP changes end
    return "".join( chars )
    
def E2A( string ):
    """Return UNICODE version of this EBCDIC string."""
    chars, used= codecs.getdecoder('cp037')(string)
    assert used == len(string)
    return str(chars)

def A2E( string ):
    chars, used= codecs.getencoder('cp037')(string)
    assert used == len(string)
    return str(chars)

# A handy hex dump printer class

class HexDump:
    """Create a Hex Dump object that can dump records from a file."""
    def __init__( self, aFile=None, rowSize=64 ):
        self.theFile= None
        if aFile:
            self.theFile= open(aFile,"rb")
        self.rows= 0
        self.hex= '0123456789ABCDEF'
        self.rowSize= rowSize
        self.positions= "".join([ ("----+----%d"%(i+1))[:10] for i in range(self.rowSize/10) ]) + "----+-----"[:self.rowSize%10]
    def hexPrint( self, row, data ):
        """Print a row of data in two-line hex format."""
        cha= []
        top= []
        bot= []
        for c in data:
            if c in ('\n','\r','\f','\t','\x00'): cha.append('.')
            else: cha.append( c )
            top.append( self.hex[ ord(c)/16 ] )
            bot.append( self.hex[ ord(c)%16 ] )
        print('%3d|' % (row*self.rowSize+1), "".join( cha ))
        print("   |", "".join(top))
        print("   |", "".join(bot))
    def dump( self, bytes=64 ):
        """Dump a record of a given length."""
        self.rows += 1
        data= self.theFile.read(bytes)
        if not data: return None
        print("record %d (%d bytes)" % (self.rows, len(data)))
        print("   |",self.positions)
        rows= len(data)/self.rowSize
        for i in range(rows):
            self.hexPrint( i, data[i*self.rowSize:(i+1)*self.rowSize] )
        self.hexPrint( rows, data[rows*self.rowSize:] )
        print()
        return self
    def dumpAll( self, bytes=64 ):
        """Dump all records in the file."""
        while self.dump(bytes):
            pass


# Two handy classes for examining individual fields

class FieldValue:
    """Accumulate unique values for a named field of a DDE.

    This will have to be subclassed for indexes of occurs clauses.
    """
    def __init__( self, dde, cobolName ):
        """Given a DDE and a COBOL name, set up a field extractor and frequency mapping."""
        self.cobolName= cobolName
        self.usage = dde.get(cobolName).usage
        self.get_field= dde.get(cobolName)
        self.domain= {}
    def getFrom( self, data ):
        """Get the value from the field, then accumulate in the frequency mapping."""
        v= self.get_field.of( data )
        self.domain[v]= self.domain.setdefault(v,0) + 1
    def fqTable( self ):
        """Return a sequence of tuples with value and frequency count, sorted."""
        val_count= list(self.domain.items())
        # Sort descending by second field (count), ascending by first field (value)
        val_count.sort( lambda a,b: cmp(b[1],a[1]) or cmp(a[0],b[0]) )
        return val_count

class NumFieldValue( FieldValue ):
    """Accumulate unique values for a named field of a DDE that is numeric.

    This will have to be subclassed for indexes of occurs clauses.
    """
    def fqTable( self ):
        """Return a sequence of tuples with value and frequency count, sorted."""
        val_count= [ (self.usage.valueOf(v),c) for v,c in list(self.domain.items()) ]
        # Sort descending by second field (count), ascending by first field (value)
        val_count.sort( lambda a,b: cmp(b[1],a[1]) or cmp(a[0],b[0]) )
        return val_count


# Handy classes for examining all fields of all records of a file.

class FieldScan:
    def __init__( self, aFieldList ):
        self.fieldList= aFieldList
    def process( self, recno, data ):
        for f in self.fieldList:
            f.getFrom( data )
    def final( self, records ):
        print("\n%d Records" % ( records ))
        for f in self.fieldList:
            print("\n%-10s %7s" % ( f.cobolName, "count" ))
            for di,c in f.fqTable():
                print("%-10s %7d" % ( di,c ))

class FieldDump( FieldScan ):
    def process( self, recno, data ):
        print("\nRecord %d" % (recno))
        for f in self.fieldList:
            v= f.get_field.of( data )
            print(" ", f.cobolName, f.usage.valueOf( v ))
    def final( self, records ):
        pass

class FileScan:
    """Basic file scanning operation."""
    def __init__( self, aDDE, aFieldProcess, aFileName ):
        self.dde= aDDE
        self.fieldProcess= aFieldProcess
        self.theFile= open( aFileName, "rb" )
        self.record= 0
    def reclen( self ):
        return self.dde.size
    def process( self, end=-1 ):
        data= self.theFile.read( self.reclen() )
        while data:
            self.record += 1
            self.fieldProcess.process( self.record, data )
            if self.record == end: break
            data= self.theFile.read( self.reclen() )
        self.theFile.close()
        self.fieldProcess.final(self.record)




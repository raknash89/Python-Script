#!/usr/bin/env python
"""Generate Sort card from Cobol Copybook that converts binar/packed 
data to display format

__author__: Ashutosh Pathak
"""

import argparse
import copybook_parser
import os
import re


# Each object of this class represents a copybook. The reason for this class to be in
# place is to expand the "OCCUR" clause thay many times, as it appears on the copybook.
class copy_book_struct(object):
    """populate copybook."""

    def __init__(self):
        self.level = ""
        self.datadef = ""
        self.times = 0
        self.contains = []

    def add_field(self, var):
        self.level = int(var.split(" ")[0])

        if var.upper().find(" OCCURS ") > 0:
            self.datadef = var.replace(
                var[var.upper().find(" OCCURS ") : var.upper().find(" TIMES ")], ""
            )
            self.datadef = self.datadef.replace(" OCCURS", "")
            self.datadef = self.datadef.replace(" TIMES", "")
            # print(self.datadef)
            self.times = int(
                var[var.upper().find(" OCCURS ") + 8 :].split(" ")[0].replace(" ", "")
            )
        else:
            self.times = 0
            self.datadef = var

        self.datadef = " ".join(self.datadef.split())


# This class helps convert the list structure of "copy_book_struct" into a str format.
class copy_book_str(object):
    """FINAL copybook."""

    def __init__(self):
        self.copystr = " " * 7

    def split_def(self, str):
        if len(str) < 65:
            return str
        return_str = ""
        str_list = str.split()
        for str in str_list:
            temp_str = return_str + str + " "
            length = len(temp_str.split("\n")[-1])
            if length > 65:
                return_str = return_str + "\n" + " " * 7 + str + " "
            else:
                return_str = temp_str
        return return_str

    def gen_struct(self, c):
        self.copystr = self.copystr + self.split_def(c.datadef) + "\n" + " " * 7
        if not c.contains:
            return
        for struct in c.contains:
            self.gen_struct(struct)


# Method to create a tree structure for the Copybook data items.
def update_contain(cstruct, obj):
    for c in cstruct[::-1]:
        if c.level < obj.level:
            c.contains.append(obj)
            if obj.times > 0:
                for _ in range(1, obj.times):
                    c.contains.append(obj)
            return


# Method to expand OCCURS.
def expand_occurs(copystr):
    variables = copystr.replace("\n", "").split(".")
    updvar = []
    for var in variables:
        if var.count(" ") != len(var):
            updvar.append(var.lstrip().rstrip() + ".")

    cstruct = []

    for var in updvar:
        c = copy_book_struct()
        c.add_field(var)
        cstruct.append(c)
        update_contain(cstruct, c)

    cbs = copy_book_str()
    cbs.gen_struct(cstruct[0])
    return cbs.copystr


def cleanup_copybook(copystr):
    skip = re.compile(r".* SKIP[0-9]? ")
    indexed_by = re.compile(r"INDEXED\s+BY\s+[:A-Z\-0-9]+")
    return_str = ""
    default_level_one = ""
    copystr_mod = re.sub(indexed_by,"",copystr)
    copy_lines = copystr_mod.replace("\x0d0a", "\n").replace("\x0d", " ").split("\n")
    first_time = 1
    activate_cond_var = 0
    for line in copy_lines:
        line = line.ljust(72)[:72]
        if line == "" or len(line) <= 6:
            continue

        if line[6] in ("*", "/"):
            continue

        line = " " * 7 + line[7:]
        if line.replace(" ", "") == "":
            continue

        if line[6] not in ("*", "/"):
            if first_time:
                if line[6:].find(" 01 ") < 0:
                    default_level_one = "       01  COPYBOOK-LEVEL-01.\n"
                first_time = 0
            if activate_cond_var:
                testlevel = line[6:72].lstrip().split()[0]
                if testlevel.isdigit():
                    activate_cond_var = 0
                else:
                    continue

            if skip.match(line[6:]):
                continue

            if line[6:].find(" 88 ") >= 0:
                if line[6:72].find(".") < 0:
                    activate_cond_var = 1
                continue
            if (
                line.replace(" ", "").find("USAGEPOINTER") > 0
                or line.replace(" ", "").find("USAGEISPOINTER") > 0
            ):
                rep_str = line[line.find("USAGE") : line.find("POINTER") + 7]
                line = line.replace(rep_str, " PIC S9(08) COMP")
            if line.replace(" ", "").find("VALUENULL") > 0:
                rep_str = line[line.find("VALUE ") : line.find("NULL") + 4]
                line = line.replace(rep_str, "")

            if line[7:].strip().find(" COPY ") >= 0:
                print("Nested copybook, expand nested copybook before processing")
                exit(0)
            if line[7:].strip().find("VALUE ") == 0:
                line = "              ."
            if line[7:].find(" BINARY ") > 0:
                line = line.replace(" BINARY ", " COMP ")
            if line[7:].find(" EJECT ") > 0:
                line = line.replace(" EJECT ", " ")

            if line[7:].find(" SYNC ") > 0:
                line = line.replace(" SYNC ", " ")
            if line[7:].find(" SYNC.") > 0:
                line = line.replace(" SYNC.", ".")
            if line[7:].replace(" ", "").find("BLANKWHENZERO") > 0:
                replace_string = line[7:][
                    line[7:].find(" BLANK ") : line[7:].find(" ZERO") + 5
                ]
                line = line.replace(replace_string, "")
            return_str = (
                return_str + "\n" + default_level_one + " " * 7 + line[7:72] + " " * 8
            )

            default_level_one = ""
    return return_str


def generate_dde(copybook_file):
    rf = copybook_parser.RecordFactory()

    copystr = open(copybook_file, "r").read()
    copystr = cleanup_copybook(copystr)

    #print("After cleanup:" + copystr)
    #exit(0)
    copystr = expand_occurs(copystr)

    #print("After expand occurs: " + copystr)
    #exit(0)
    dde = rf.makeRecord(copybook_parser.Lexer(copystr))

    cum_offset = 0
    dde.populate_cum_offset(cum_offset)

    return dde


def report_offset(dde):
    rpt = copybook_parser.Report()
    dde.visit(rpt)


def process_file(dde,data_file_path,ebcdic_flag,output_file_path):
    data_file = open(data_file_path,mode="rb")
    file_info = os.stat(data_file_path)
    file_size = file_info.st_size
    lrecl=dde.size
    if file_size % lrecl !=0:
        print("Mismatch in file length and copybook")
        exit(8)

    elem_field_list = []
    field_end_pos = [-1]   # Array for ignoring redefine
    populate_elem_field(dde,elem_field_list,field_end_pos)
    #print(elem_field_list)

    output_file = open(output_file_path,"w")
    header = ",".join([field.myName for field in elem_field_list])
    output_file.write(header + "\n")

    record = 0
    record_list = []
    data =data_file.read(lrecl)    
    while data:
        record+=1
        #print("Displaying record number",record)
        for field in elem_field_list:
            if ebcdic_flag:
                record_list.append(str(field.valOf(data,True)))
            else:
                record_list.append(str(field.valOf(data,False)))
        data =data_file.read(lrecl)
        #print(record_list)
        output_file.write(",".join(record_list)+"\n")
        record_list = []


def populate_elem_field(dde, elem_field_list,field_end_pos):
    if dde.level == "88":
        return

    if not dde.contains:
        if dde.cumoffset > field_end_pos[-1]: # Logic to ignore redefine
            elem_field_list.append(dde)
            field_end_pos.append(dde.cumoffset + dde.size - 1)
    if dde.contains:
        for f in dde.contains:
            populate_elem_field(f, elem_field_list,field_end_pos)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "-c",
        "--copybook",
        type=str,
        default="",
        help="specify file layout aka Copybook",
        required=True
    )
    parser.add_argument(
        "-f",
        "--file",
        type=str,
        default="",
        help="Specify input file to be read"
        #required=True,
    )
    parser.add_argument(
        "-e",
        "--ebcdic_flag",
        action="store_true",
        help="Flag for ebcdic data",
    )
    parser.add_argument(
        "-o",
        "--output_file",
        type=str,
        default="",
        help="Specify Output CSV file"
        #required=True
    )

    parser.add_argument(
        "-r",
        "--report_offset",
        action="store_true",
        default=False,
        help="Print offset of copybook vars",
    )

    args = parser.parse_args()

    if args.copybook == "":
        parser.print_help()
        exit(4)
    else:
        if not os.path.isfile(args.copybook):
            print("Copybook File not present -", args.copybook)
            exit(8)
    
    copybook_file = args.copybook
    dde = generate_dde(copybook_file)

    if args.report_offset:
        report_offset(dde)


    if args.file != "":
        if not os.path.isfile(args.file):
            print("Data File not present -", args.file)
            exit(8)

    data_file_path = args.file
    


    output_file_path = args.output_file
    if args.file:
        process_file(dde,data_file_path,args.ebcdic_flag,output_file_path)

#!/usr/bin/env python


import re
import struct
import string
import decimal
from data_profile import *


class SyntaxError(Exception):
    """COBOL syntax error."""

    pass


class UnsupportedError(Exception):
    """A COBOL DDE has features not supported by this module."""

    pass


class UsageError(Exception):
    """A COBOL DDE is not used properly, e.g., occurs-clause out of range."""

    pass


# 1. Basic class definitions


class Visitor(object):
    """Visits each node of a DDE, doing a depth-first traversal of the structure."""

    def __init__(self):
        self.indent = 0

    def enterSub(self):
        self.indent += 1

    def exitSub(self):
        self.indent -= 1

    def dde(self, aDDE):
        """Given a DDE, perform the requested process."""
        pass

    def finish(self):
        """Any summary information at the end of the visit."""
        pass


class Usage(object):
    """Covert numeric data based on Usage clause."""

    def __init__(self, name_):
        self.myName = name_
        self.numeric = None
        self.originalSize = None
        self.scale = None
        self.precision = None
        self.signed = None

    def setTypeInfo(self, **typeInfo):
        """After parsing a PICTURE clause, provide additional usage information."""
        self.numeric = typeInfo["numeric"]
        self.originalSize = typeInfo["length"]
        self.scale = typeInfo["scale"]
        self.precision = typeInfo["precision"]
        self.signed = typeInfo["signed"]
        self.decimal = typeInfo["decimal"]

    def valueOf(self, buffer):
        """Convert this data to a decimal number."""
        return None

    def size(self, picture):
        """Return the actual size of this data, based on PICTURE and SIGN."""
        return len(picture)


class UsageDisplay(Usage):
    """Convert from ordinary character data to numeric."""

    # NOTE: EBCDIC->ASCII conversion handled by the DDE as a whole.
    def __init__(self):
        Usage.__init__(self, "DISPLAY")

    def valueOf(self, buffer, convert=False):
        if self.numeric and self.precision != 0:
            if self.decimal == ".":
                # FIX FOR FIELDS THAT DON'T MAP OK. IGNORE ERROR AND RETURN HEX EQUIVALENT START
                try:
                    return decimal.Decimal(buffer)
                except Exception:
                    return "HEX: " + buffer.encode("hex")
            # FIX FOR FIELDS THAT DON'T MAP OK. IGNORE ERROR AND RETURN HEX EQUIVALENT ENDS
            if self.signed:
                data_nibble = repr(struct.unpack("B", buffer[-1:])[0] % 16)
                sign_nibble = repr(struct.unpack("B", buffer[-1:])[0] // 16)
                if convert:
                    buffer = E2A_str(buffer[0 : len(buffer) - 1])
                    compare_nibble = "13"
                else:
                    buffer = buffer[0 : len(buffer) - 1]
                    compare_nibble = "7"
                buffer = buffer + data_nibble
                # FIX FOR FIELDS THAT DON'T MAP OK. IGNORE ERROR AND RETURN HEX EQUIVALENT START
                try:
                    f = decimal.Decimal(
                        buffer[: -self.precision] + "." + buffer[-self.precision :]
                    )
                except Exception:
                    return "HEX: " + buffer.encode("hex")
                # FIX FOR FIELDS THAT DON'T MAP OK. IGNORE ERROR AND RETURN HEX EQUIVALENT ENDS
                if sign_nibble == compare_nibble:
                    return -f
                else:
                    return f
            # FIX FOR FIELDS THAT DON'T MAP OK. IGNORE ERROR AND RETURN HEX EQUIVALENT START
            try:
                return decimal.Decimal(
                    buffer[: -self.precision] + "." + buffer[-self.precision :]
                )
            except Exception:
                return "HEX: " + buffer.encode("hex")
            # FIX FOR FIELDS THAT DON'T MAP OK. IGNORE ERROR AND RETURN HEX EQUIVALENT ENDS

        elif self.numeric and self.precision == 0:
            #AP changes start
            if self.signed:
                data_nibble = repr(struct.unpack("B", buffer[-1:])[0] % 16)
                sign_nibble = repr(struct.unpack("B", buffer[-1:])[0] // 16)
                if convert:
                    buffer = E2A_str(buffer[0 : len(buffer) - 1])
                    compare_nibble = "13"
                else:
                    buffer = buffer[0 : len(buffer) - 1]
                    compare_nibble = "7"
                buffer = buffer + data_nibble
                if sign_nibble == compare_nibble:
                    return int(buffer) * -1
                else:
                    return int(buffer)
            #AP changes end
            if not buffer.isdigit():
                #buffer = "0" * self.originalSize
                buffer = "Invalid Number"
                return buffer
            return int(buffer)
        return buffer


class UsageComp(Usage):
    """Convert from COMP data to numeric.

    This may need to be overridden to handle little-endian data."""

    def __init__(self):
        Usage.__init__(self, "COMP")

    def valueOf(self, buffer, convert=False):
        n = struct.unpack(self.sc, buffer)
        return decimal.Decimal(n[0])

    def size(self, picture):
        if len(picture) <= 4:
            self.sc = ">h"
            return 2
        elif len(picture) <= 9:
            self.sc = ">i"
            return 4
        else:
            self.sc = ">q"
            return 8


class UsageComp3(Usage):
    """Convert from COMP-3 data to numeric."""

    def __init__(self):
        Usage.__init__(self, "COMP-3")

    def valueOf(self, buffer, convert=False):

        display = []
        #for c in buffer:
        for i in range(len(buffer)):
            #n = struct.unpack("B", c)
            n = struct.unpack("B", buffer[i:i+1])
            #display.append(str(n[0] / 16))
            display.append(str(n[0] // 16))
            display.append(str(n[0] % 16))
        # print repr(buffer), repr(display)
        # Last position has sign information: 'd' is <0, 'f' is unsigned, and 'c' >=0
        f = decimal.Decimal("".join(display[:-1]))

        if self.numeric and self.precision != 0:
            if self.decimal != ".":
                f = decimal.Decimal(
                    "".join(display[:-1])[: -self.precision]
                    + "."
                    + "".join(display[:-1])[-self.precision :]
                )

        #if display[-1] == 13:
        if display[-1] == "13":
            return -f
        return f

    def size(self, picture):
        return int((len(picture) + 2) / 2)


class Redefines(object):
    """Lookup size and offset from the field we rename."""

    def __init__(self, name_=None):
        self.myName = name_

    def offset(self, offset, aDDE):
        return aDDE.top.get(self.myName).offset

    def indexedOffset(self, offset, aDDE):
        return aDDE.top.get(self.myName).indexedOffset

    def size(self, aDDE):
        return 0


class NonRedefines(Redefines):
    """More typical case is that we have our own size and offset."""

    def offset(self, offset, aDDE):
        return offset

    def indexedOffset(self, offset, aDDE):
        return offset + aDDE.occurSize * aDDE.currentIndex

    def size(self, aDDE):
        return aDDE.size


# 2. DDE class definition


class DDE(object):
    """A Data Description Entry.

    This is either a group-level item, which contains DDE's, or
    it is a lowest-level DDE, defined by a PICTURE clause.
    All higher-level DDE's are effectively string-type data.
    A lowest-level DDE with a numeric PICTURE is numeric-type data.
    Occurs and Redefines can occur at any level.  Almost anything
    can be combined with anything else.

    Each entry is defined by the following attributes
        level       COBOL level number 01 to 49, 66 or 88.
        myName      COBOL variable name
        occurs      the number of occurances (default is 1)
        picture     the exploded picture clause, with ()'s expanded
        initValue   any initial value provided
        offset      offset to this field from start of record
        cumoffset   cumulative offset to this field from start of record
        size        overall size of this item, including all occurances
        occurSize   the size of an individual occurance
        sizeScalePrecision  ( numeric, size, scale (# of P's), precision)
        redefines   an instance of Redefines used to compute the offset
        usage       an instance of Usage used to do data conversions
        contains    the list of contained fields
        parent      the immediate parent DDE
        top         the overall record definition DDE
        currentIndex    the current index values used for locating data
        indexedOffset   the current offset based on current index values

    The primary interface is get(), setIndex(), of() and valOf().
    get('dataname') returns the DDE for the given dataname
    setIndex(x,...) sets the current indexes for the various occurs clauses
    of(record) locates this DDE's bytes within the given record
    valOf(record) locates this DDE's bytes and interprets them as a number
    """

    def __init__(
        self,
        level,
        name_,
        usage=None,
        pic=None,
        occurs=None,
        redefines=None,
        ssp=(None, None, None, None),
        initValue=None,
    ):
        self.level = level
        self.myName = name_
        self.offset = 0
        self.cumoffset = 0
        self.size = 0
        self.occurs = occurs
        self.occurSize = None
        self.picture = pic
        self.sizeScalePrecision = ssp
        self.redefines = redefines
        self.usage = usage
        self.initValue = initValue
        self.contains = []
        self.parent = None
        self.top = None
        self.currentIndex = 0
        self.indexedOffset = None

    def __repr__(self):
        return "%s %s %s" % (self.level, self.myName, list(map(str, self.contains)))

    def convert_pic(self):
        if self.picture is None:
            return self.picture

        if self.picture.count("X") > 0:
            return "X(" + repr(self.picture.count("X")) + ")"

        if self.picture.count("9") > 0:
            return "9(" + repr(self.picture.count("9")) + ")"

    def __str__(self):
        oc = ""
        pc = ""
        rc = ""
        if self.occurs > 1:
            oc = " OCCURS %s" % self.occurs
        # if self.picture: pc= " PIC %s USAGE %s" % ( self.picture, self.usage.myName )
        if self.picture:
            pc = ' "PIC %s"," USAGE %s"' % (self.convert_pic(), self.usage.myName)
        if self.redefines.myName:
            rc = " REDEFINES %s" % (self.redefines.myName)

        if self.picture is None:
            pc = '"GROUP","-"'

        return '"%-2s"," %-20s","%s - %s ","%s"' % (self.level, self.myName, rc, oc, pc)

    def populate_cum_offset(self, cum_offset):
        """Visit this DDE and each element."""
        if self.level == "88":
            return
        cum_offset = cum_offset + self.indexedOffset

        self.cumoffset = cum_offset
        indent_spaces = 70 - len(str(self))
        if indent_spaces < 0:
            indent_spaces = 0
        # print '"', self ,'","', self.indexedOffset, '","', cum_offset, '","', self.size, '"\n',

        if self.contains:
            for f in self.contains:
                f.populate_cum_offset(cum_offset)

    def append(self, aDDE):
        """Add a substructure to this DDE.

        This is used by RecordFactory to assemble the DDE."""
        self.contains.append(aDDE)
        aDDE.parent = self

    def setTop(self, topDDE):
        """Set the immediate parentage and top-level record for this DDE.

        Used by RecordFactory to assemble the DDE.
        Required before setSizeAndOffset()."""
        self.top = topDDE
        for f in self.contains:
            f.parent = self
            f.setTop(topDDE)

    def setSizeAndOffset(self, offset=0):
        """Compute the size and offset for each field of this DDE.

        Used by RecordFactory to assemble the DDE.
        Requires setTop be done first.

        Note: 88-level items inherit attributes from their parent.
        """
        # Wire in a single occurance, it simplifies the math, below.
        if not self.occurs:
            self.occurs = 1
        # If this is a redefines, get a different offset, otherwise use this offset
        self.offset = self.redefines.offset(offset, self)
        # Set the default indexedOffset
        self.indexedOffset = self.offset
        # PICTURE - elementary item; otherwise group-level item
        if self.picture:
            # Get the correct size based on USAGE
            self.occurSize = self.usage.size(self.picture)
            self.size = self.occurSize * self.occurs
            # Any contained items?  These would be 88-level items.
            for f in self.contains:
                # assert '88' == f.level, "Unexpected Level {0!r}".format(f.level)
                f.setSizeAndOffset(self.offset)
        elif self.level == "88":
            self.occurSize = self.parent.occurSize
            self.size = self.parent.size
            self.usage = self.parent.usage
        else:
            # Get the correct size based on each element of the group
            s = 0  # Was self.offset???? Wasn't That Funny?
            for f in self.contains:
                # Element size and offset
                f.setSizeAndOffset(s)
                # non-redefines add to the size; redefines add 0 to the size
                s += f.redefines.size(f)
            self.occurSize = s
            # Multiply by the number of occurances to get the total size
            self.size = self.occurSize * self.occurs

    def visit(self, visitor):
        """Visit this DDE and each element."""
        visitor.dde(self)
        if self.contains:
            visitor.enterSub()

            for f in self.contains:
                f.visit(visitor)
            visitor.exitSub()

    def visitOccurance(self, visitor):
        """Visit each occurance of this DDE
        and each occurance of each element."""
        if not self.occurs:
            return
        for self.currentIndex in range(0, self.occurs):
            self.top.setIndexedOffset(0)  # compute offsets for this new index value
            visitor.dde(self)
            if self.contains:
                visitor.enterSub()
                for f in self.contains:
                    f.visitOccurance(visitor)
                visitor.exitSub()

    def pathTo(self):
        """Return the complete path to this DDE."""
        if self.parent:
            return self.parent.pathTo() + "." + self.myName
        return self.myName

    def get(self, name_):
        """Find the named field, and return the substructure.

        If necessary, search down through levels."""
        for c in self.contains:
            if c.myName == name_:
                return c
        for c in self.contains:
            try:
                f = c.get(name_)
                if f:
                    return f
            except UsageError as e:
                pass
        raise UsageError("Field %s unknown in this record" % name_)

    def setIndex(self, *occurance):
        """Set the index values for locating specific data bytes."""
        # Handles multi-dimensional short-cut syntax.
        # Work up through parentage to locate occurs clauses and pop off indexes
        if self.occurs > 1:
            if self.occurs < occurance[-1] or occurance[-1] <= 0:
                raise UsageError("Occurs value %r out of bounds %r" % (occurance, self))
            self.currentIndex = occurance[-1] - 1
            # print self.myName, 'occurs', self.occurs, 'index', self.currentIndex+1
            # Recursive call to setIndex for all remaining index values.
            if occurance[:-1]:
                self.parent.setIndex(*occurance[:-1])
        else:
            # print self.myName, 'search upward',repr(occurance)
            self.parent.setIndex(*occurance)
        # Compute offsets for these new index values
        self.top.setIndexedOffset(0)
        return self

    def setIndexedOffset(self, offset=0):
        """Given index values, compute the indexed offsets into occurs clauses.

        Used by setIndex to compute indexed offsets."""
        # TODO: may be able to eliminate this if-statement!
        if self.occurSize:
            # Redefines will use an offset from another field, otherwise use the offset provided
            self.indexedOffset = self.redefines.indexedOffset(offset, self)
            s = self.indexedOffset
            for f in self.contains:
                # Update elements within this group
                f.setIndexedOffset(s)
                # Redefines add zero to the size, otherwise increment offset with the size
                s += f.redefines.size(f)

    def of(self, aString):
        """Pick the data bytes out of an input string.

        TODO: May require EBCDIC->ASCII conversion.

        Requires setIndexedOffset() call if indexes were changed without calling setIndex()
        Use valOf to handle packed decimal data (USAGE COMP-3).
        """
        b = self.cumoffset
        return aString[b : b + self.occurSize]

    def valOf(self, aString, convert):
        """Pick the data bytes out of an input string and interpret as a number."""
        if convert and (
            self.usage.myName != "COMP-3"
            and self.usage.myName != "COMP"
            and not self.usage.signed
        ):
            bytes = E2A_str(self.of(aString))
        else:
            bytes = self.of(aString)
        return self.usage.valueOf(bytes, convert)


# 3. Some utility classes for reporting


class Source(Visitor):
    """Display canonical source from copybook parsing."""

    def dde(self, aDDE):
        print(self.indent * "  ", aDDE)


class Report(Visitor):
    """Report on copybook structure."""

    def dde(self, aDDE):
        numeric, size, scale, precision = aDDE.sizeScalePrecision
        if numeric:
            # AP changes start
            # nSpec= '%d.%d' % ( size, precision )
            nSpec = "%d.%d" % (size - precision, precision)
            # AP changes end
        else:
            nSpec = ""
        print(
            "%-65s, %3d, %3d, %5s"
            % (self.indent * "  " + str(aDDE), aDDE.cumoffset, aDDE.size, nSpec)
        )


class Dump(Visitor):
    """Dump the data values of this structure."""

    def __init__(self, data):
        Visitor.__init__(self)
        self.data = data

    def dde(self, aDDE):
        db = aDDE.of(self.data)
        dstr = []
        for c in db:
            dstr.append("%2s" % hex(ord(c))[2:])
        r = " ".join(dstr)  # or r=db
        if aDDE.occurs > 1:
            print(
                "%-65s %3d %3d %3d '%s'"
                % (
                    self.indent * "  " + str(aDDE),
                    aDDE.indexedOffset,
                    aDDE.size,
                    aDDE.currentIndex + 1,
                    r,
                )
            )
        elif aDDE.picture and aDDE.myName != "FILLER":
            print(
                "%-65s %3d %3d '%s'"
                % (self.indent * "  " + str(aDDE), aDDE.indexedOffset, aDDE.size, r)
            )
        else:
            print(
                "%-65s %3d %3d"
                % (self.indent * "  " + str(aDDE), aDDE.indexedOffset, aDDE.size)
            )


# 4. The Lexical Scanning and Parsing of an input record layout


class Lexer(object):
    """Lexical scanner for COBOL.

    Given a block of text, this scanner will remove comment lines.
    next() will step through the tokens
    unget(token) will back up a token
    """

    def __init__(self, text):
        """Initialize the scanner by cleaning the text."""
        self.lines = self.lineClean(text)
        self.backup = []
        self.separator = re.compile(r"[.,;]?\s")
        self.quote1 = re.compile(r"'[^']*'")
        self.quote2 = re.compile(r'"[^"]*"')

    def lineClean(self, text):
        lines = [
            l[6:72].rstrip() + " "
            for l in text.split("\n")
            if len(l) > 6 and l[6] not in ("*", "/")
        ]
        lines = [l for l in lines if l.strip() != "SKIP1"]
        return lines


    def __next__(self):
        """Locate the next token in the input stream."""
        if self.backup:
            return self.backup.pop()
        # print "self.lines=", self.lines
        if not self.lines[0]:
            self.lines.pop(0)
        if not self.lines:
            print("EOF")
            return None
        while self.lines and self.lines[0] and self.lines[0][0] in string.whitespace:
            self.lines[0] = self.lines[0].lstrip()
            if not self.lines[0]:
                self.lines.pop(0)
            if not self.lines:
                return None
        if self.lines[0][0] == "'":
            # quoted string, break on balancing quote
            match = self.quote1.match(self.lines[0])
            space = match.end()
        elif self.lines[0][0] == '"':
            # quoted string, break on balancing quote
            match = self.quote2.match(self.lines[0])
            space = match.end()
        else:
            match = self.separator.search(self.lines[0])
            space = match.start()
            if space == 0:  # starts with separator
                space = match.end() - 1
        token, self.lines[0] = self.lines[0][:space], self.lines[0][space:]
        # print token
        return token

    def unget(self, token):
        """Push one token back into the input stream."""
        self.backup.append(token)


class RecordFactory(object):
    """Parse a copybook, creating a DDE structure."""

    def __init__(self):
        self.lex = None
        self.token = None
        self.context = []
        self.noisewords = ("WHEN", "IS", "TIMES")
        self.keywords = (
            "BLANK",
            "ZERO",
            "ZEROS",
            "ZEROES",
            "DATE",
            "FORMAT",
            "EXTERNAL",
            "GLOBAL",
            "JUST",
            "JUSTIFIED",
            "LEFT",
            "RIGHT" "OCCURS",
            "PIC",
            "PICTURE",
            "REDEFINES",
            "RENAMES",
            "SIGN",
            "LEADING",
            "TRAILING",
            "SEPARATE",
            "CHARACTER",
            "SYNCH",
            "SYNCHRONIZED",
            "USAGE",
            "DISPLAY",
            "COMP-3",
            "VALUE",
            ".",
        )

    def picParse(self, pic):
        """Rewrite a picture clause to eliminate ()'s, S's, V's, P's, etc.
        print self.token
        Returns expanded, normalized picture and (type,length,scale,precision,signed) information.
        """
        out = []
        scale, precision, signed, decimal = 0, 0, False, None
        while pic:
            c = pic[:1]
            if c in ("A", "B", "X", "Z", "9", "0", "/", ",", "+", "-", "*", "$"):
                out.append(c)
                if decimal:
                    precision += 1
                pic = pic[1:]
            elif pic[:2] in ("DB", "CR"):
                out.append(pic[:2])
                pic = pic[2:]
            elif c == "(":
                irpt = 0
                pic = pic[1:]
                # A regular expression may be quicker and simpler!
                try:
                    while pic and pic[:1].isdigit():
                        irpt = 10 * irpt + int(pic[:1])
                        pic = pic[1:]
                except ValueError as t:
                    raise SyntaxError("picture error in %r" % pic)
                out.append((irpt - 1) * out[-1])
                assert pic[0] == ")", SyntaxError("picture error in %r" % pic)
                pic = pic[1:]
                if decimal:
                    precision += irpt - 1
            elif c == "S":
                # silently drop an "S".
                # Note that 'S' plus a SIGN SEPARATE option increases the size of the picture!
                signed = True
                pic = pic[1:]
            elif c == "P":
                # silently drop a "P", since it just sets scale and isn't represented.
                scale += 1
                pic = pic[1:]
            elif c == "V":
                decimal = "V"
                pic = pic[1:]
            elif c == ".":
                decimal = "."
                out.append(".")
                pic = pic[1:]
            else:
                raise SyntaxError("picture error in %s" % pic)

        final = "".join(out)
        alpha = ("A" in final) or ("X" in final) or ("/" in final)
        # print pic, final, alpha, scale, precision
        # Note: Actual size depends on len(final) and usage!
        return dict(
            final=final,
            alpha=alpha,
            numeric=not alpha,
            length=len(final),
            scale=scale,
            precision=precision,
            signed=signed,
            decimal=decimal,
        )

    def picture(self):
        """Parse a PICTURE clause."""
        if self.token == "IS":
            self.token = next(self.lex)
        pic = next(self.lex)
        self.token = next(self.lex)
        return self.picParse(pic)

    def blankWhenZero(self):
        """Gracefully skip over a BLANK WHEN ZERO clause."""
        self.token = next(self.lex)
        if self.token == "WHEN":
            self.token = next(self.lex)
        if self.token in ("ZERO", "ZEROES", "ZEROS"):
            self.token = next(self.lex)

    def justified(self):
        """Gracefully skip over a JUSTIFIED clause."""
        self.token = next(self.lex)
        if self.token == "RIGHT":
            self.token = next(self.lex)

    def occurs(self):
        """Parse an OCCURS clause."""
        occurs = next(self.lex)
        if occurs == "TO":
            # format 2 - occurs depending on with assumed 1 for the lower limit
            # TODO - parse the Occurs Depending On clause
            raise UnsupportedError("Occurs depending on")
        self.token = next(self.lex)
        if self.token == "TO":
            # format 2 - occurs depending on
            # TODO - parse the Occurs Depending On clause
            raise UnsupportedError("Occurs depending on")
        else:
            # format 1 - fixed-length
            if self.token == "TIMES":
                self.token = next(self.lex)
            if self.token in ("ASCENDING", "DESCENDING"):
                self.token = next(self.lex)
            if self.token == "KEY":
                self.token = next(self.lex)
            if self.token == "IS":
                self.token = next(self.lex)
            # get key data names
            while self.token not in self.keywords:
                self.token = next(self.lex)
            if self.token == "INDEXED":
                self.token = next(self.lex)
            if self.token == "BY":
                self.token = next(self.lex)
            # get indexed data names
            while self.token not in self.keywords:
                self.token = next(self.lex)
            return int(occurs)

    def redefines(self):
        """Parse a REDEFINES clause."""
        redef = next(self.lex)
        self.token = next(self.lex)
        return Redefines(redef)

    def renames(self):
        """Raise an exception on a RENAMES clause."""
        ren1 = next(self.lex)
        self.token = next(self.lex)
        if self.token in ("THRU", "THROUGH"):
            ren2 = next(self.lext)
            self.token = next(self.lex)
        raise UnsupportedError("Renames clause")

    def sign1(self):
        """Raise an exception on a SIGN clause."""
        self.token = next(self.lex)
        if self.token == "IS":
            self.token = next(self.lex)
        if self.token in ("LEADING", "TRAILING"):
            self.sign2()
        # TODO: this may change the size to add a sign byte
        raise UnsupportedError("Sign clause")

    def sign2(self):
        """Raise an exception on a SIGN clause."""
        self.token = next(self.lex)
        if self.token == "SEPARATE":
            self.token = next(self.lex)
        if self.token == "CHARACTER":
            self.token = next(self.lex)
        raise UnsupportedError("Sign clause")

    def synchronized(self):
        """Raise an exception on a SYNCHRONIZED clause."""
        self.token = next(self.lex)
        if self.token == "LEFT":
            self.token = next(self.lex)
        if self.token == "RIGHT":
            self.token = next(self.lex)
        raise UnsupportedError("Synchronized clause")

    def usage(self):
        """Parse a USAGE clause."""
        self.token = next(self.lex)
        if self.token == "IS":
            self.token = next(self.lex)
        use = self.token
        self.token = next(self.lex)
        return self.usage2(use)

    def usage2(self, use):
        """Create a correct Usage instance based on the USAGE clause."""
        if use == "DISPLAY":
            return UsageDisplay()
        elif use == "COMPUTATIONAL":
            return UsageComp()
        elif use == "COMP":
            return UsageComp()
        elif use == "COMPUTATIONAL-3":
            return UsageComp3()
        elif use == "COMP-3":
            return UsageComp3()
        else:
            raise SyntaxError("Unknown usage clause %r" % use)

    def value(self):
        """Parse a VALUE clause."""
        if self.token == "IS":
            self.token = next(self.lex)
        lit = next(self.lex)
        self.token = next(self.lex)
        return lit

    def makeDDE(self):
        """Create a single DDE from an entry of clauses."""
        # Pick off the level
        level = self.token
        # Pick off a name, if present
        name_ = next(self.lex)
        if name_ in self.keywords:
            self.lex.unget(name_)
            name_ = "FILLER"
        # Accumulate the relevant clauses, dropping noise words and irrelevant clauses.
        usage = UsageDisplay()
        pic, typeInfo = None, None
        occurs = None
        redefines = NonRedefines()
        self.token = next(self.lex)
        while self.token and self.token != ".":
            if self.token == "BLANK":
                self.blankWhenZero()
            elif self.token in ("EXTERNAL", "GLOBAL"):
                self.token = next(self.lex)
            elif self.token in ("JUST", "JUSTIFIED"):
                self.justified()
            elif self.token == "OCCURS":
                occurs = self.occurs()
            elif self.token in ("PIC", "PICTURE"):
                self.typeInfo = self.picture()
                pic = self.typeInfo["final"]
            elif self.token == "REDEFINES":
                redefines = self.redefines()
            elif self.token == "RENAMES":
                self.renames()
            elif self.token == "SIGN":
                self.sign1()
            elif self.token in ("LEADING", "TRAILING"):
                self.sign2()
            elif self.token == "SYNCHRONIZED":
                self.synchronized()
            elif self.token == "USAGE":
                usage = self.usage()
            elif self.token == "VALUE":
                self.value()
            else:
                try:
                    # Keyword USAGE is optional
                    usage = self.usage2(self.token)
                    self.token = next(self.lex)
                except SyntaxError as e:
                    print(self.token)
                    raise SyntaxError("%s unrecognized" % self.token)
        # Create the DDE and return it
        # TODO: Add a subclass for elementary items different from group-level items
        if pic:
            # print "FIELD NAME: ",name_
            # AP Sart
            ssp = (
                self.typeInfo["numeric"],
                self.typeInfo["length"],
                self.typeInfo["scale"],
                self.typeInfo["precision"],
            )
            # AP end
            usage.setTypeInfo(**self.typeInfo)
            return DDE(
                level,
                name_,
                pic=pic,
                usage=usage,
                occurs=occurs,
                redefines=redefines,
                ssp=ssp,
            )
        else:
            return DDE(level, name_, occurs=occurs, usage=usage, redefines=redefines)

    def makeRecord(self, lex):
        """Parse an entire copybook block of text."""
        self.lex = lex
        self.token = next(self.lex)
        # Parse the first DDE and establish the context stack.
        self.context = [self.makeDDE()]
        self.token = next(self.lex)
        while self.token:
            # Parse the next DDE
            dde = self.makeDDE()
            # print "DDE: ", dde, ":", self.context[-1], '\n'
            # If a lower level # or same level #, pop context
            while dde.level <= self.context[-1].level:
                if self.context[-1].level == "01":
                    print(
                        "Multiple copybooks detected, seperate copybooks and parse!!!"
                    )
                    exit(0)
                self.context.pop()
            # Make this DDE part of the parent DDE at the top of the context stack
            self.context[-1].append(dde)
            # Push this DDE onto the context stack
            self.context.append(dde)
            # Get the first token of the next DDE or find the end of the file
            self.token = next(self.lex)
        # Decorate the parse tree with parentage and basic size/offset information
        rec = self.context[0]
        rec.setTop(rec)
        rec.setSizeAndOffset(0)
        return rec

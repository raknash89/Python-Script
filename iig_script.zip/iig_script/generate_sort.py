#!/usr/bin/env python
"""Generate Sort card from Cobol Copybook that converts binar/packed 
data to display format

__author__: Ashutosh Pathak
"""

import argparse
import copybook_parser
import os
import re


# Each object of this class represents a copybook. The reason for this class to be in
# place is to expand the "OCCUR" clause thay many times, as it appears on the copybook.
class copy_book_struct(object):
    """populate copybook."""

    def __init__(self):
        self.level = ""
        self.datadef = ""
        self.times = 0
        self.contains = []

    def add_field(self, var):
        self.level = int(var.split(" ")[0])

        if var.upper().find(" OCCURS ") > 0:
            self.datadef = var.replace(
                var[var.upper().find(" OCCURS ") : var.upper().find(" TIMES ")], ""
            )
            self.datadef = self.datadef.replace(" OCCURS", "")
            self.datadef = self.datadef.replace(" TIMES", "")
            # print(self.datadef)
            self.times = int(
                var[var.upper().find(" OCCURS ") + 8 :].split(" ")[0].replace(" ", "")
            )
        else:
            self.times = 0
            self.datadef = var

        self.datadef = " ".join(self.datadef.split())


# This class helps convert the list structure of "copy_book_struct" into a str format.
class copy_book_str(object):
    """FINAL copybook."""

    def __init__(self):
        self.copystr = " " * 7

    def split_def(self, str):
        if len(str) < 65:
            return str
        return_str = ""
        str_list = str.split()
        for str in str_list:
            temp_str = return_str + str + " "
            length = len(temp_str.split("\n")[-1])
            if length > 65:
                return_str = return_str + "\n" + " " * 7 + str + " "
            else:
                return_str = temp_str
        return return_str

    def gen_struct(self, c):
        self.copystr = self.copystr + self.split_def(c.datadef) + "\n" + " " * 7
        if not c.contains:
            return
        for struct in c.contains:
            self.gen_struct(struct)


# Method to create a tree structure for the Copybook data items.
def update_contain(cstruct, obj):
    for c in cstruct[::-1]:
        if c.level < obj.level:
            c.contains.append(obj)
            if obj.times > 0:
                for _ in range(1, obj.times):
                    c.contains.append(obj)
            return


# Method to expand OCCURS.
def expand_occurs(copystr):
    variables = copystr.replace("\n", "").split(".")
    updvar = []
    for var in variables:
        if var.count(" ") != len(var):
            updvar.append(var.lstrip().rstrip() + ".")

    cstruct = []

    for var in updvar:
        c = copy_book_struct()
        c.add_field(var)
        cstruct.append(c)
        update_contain(cstruct, c)

    cbs = copy_book_str()
    cbs.gen_struct(cstruct[0])
    return cbs.copystr


def cleanup_copybook(copystr):
    skip = re.compile(r".* SKIP[0-9]? ")
    indexed_by = re.compile(r"INDEXED\s+BY\s+[:A-Z\-0-9]+")
    return_str = ""
    default_level_one = ""
    copystr_mod = re.sub(indexed_by,"",copystr)
    copy_lines = copystr_mod.replace("\x0d0a", "\n").replace("\x0d", " ").split("\n")
    first_time = 1
    activate_cond_var = 0
    for line in copy_lines:
        line = line.ljust(72)[:72]
        if line == "" or len(line) <= 6:
            continue

        if line[6] in ("*", "/"):
            continue

        line = " " * 7 + line[7:]
        if line.replace(" ", "") == "":
            continue

        if line[6] not in ("*", "/"):
            if first_time:
                if line[6:].find(" 01 ") < 0:
                    default_level_one = "       01  COPYBOOK-LEVEL-01.\n"
                first_time = 0
            if activate_cond_var:
                testlevel = line[6:72].lstrip().split()[0]
                if testlevel.isdigit():
                    activate_cond_var = 0
                else:
                    continue

            if skip.match(line[6:]):
                continue

            if line[6:].find(" 88 ") >= 0:
                if line[6:72].find(".") < 0:
                    activate_cond_var = 1
                continue
            if (
                line.replace(" ", "").find("USAGEPOINTER") > 0
                or line.replace(" ", "").find("USAGEISPOINTER") > 0
            ):
                rep_str = line[line.find("USAGE") : line.find("POINTER") + 7]
                line = line.replace(rep_str, " PIC S9(08) COMP")
            if line.replace(" ", "").find("VALUENULL") > 0:
                rep_str = line[line.find("VALUE ") : line.find("NULL") + 4]
                line = line.replace(rep_str, "")

            if line[7:].strip().find(" COPY ") >= 0:
                print("Nested copybook, expand nested copybook before processing")
                exit(0)
            if line[7:].strip().find("VALUE ") == 0:
                line = "              ."
            if line[7:].find(" BINARY ") > 0:
                line = line.replace(" BINARY ", " COMP ")
            if line[7:].find(" EJECT ") > 0:
                line = line.replace(" EJECT ", " ")

            if line[7:].find(" SYNC ") > 0:
                line = line.replace(" SYNC ", " ")
            if line[7:].find(" SYNC.") > 0:
                line = line.replace(" SYNC.", ".")
            if line[7:].replace(" ", "").find("BLANKWHENZERO") > 0:
                replace_string = line[7:][
                    line[7:].find(" BLANK ") : line[7:].find(" ZERO") + 5
                ]
                line = line.replace(replace_string, "")
            return_str = (
                return_str + "\n" + default_level_one + " " * 7 + line[7:72] + " " * 8
            )

            default_level_one = ""
    return return_str


def generate_dde(copybook_file):
    rf = copybook_parser.RecordFactory()

    copystr = open(copybook_file, "r").read()
    copystr = cleanup_copybook(copystr)

    #print("After cleanup:" + copystr)
    #exit(0)
    copystr = expand_occurs(copystr)

    #print("After expand occurs: " + copystr)
    #exit(0)
    dde = rf.makeRecord(copybook_parser.Lexer(copystr))

    cum_offset = 0
    dde.populate_cum_offset(cum_offset)

    return dde


def report_offset(dde):
    rpt = copybook_parser.Report()
    dde.visit(rpt)


def generate_sort(dde,input_dsn,sort_dsn):
    sort_list = []
    field_len = []
    field_end_pos = [-1]
    gen_sort_outrec(dde, sort_list, field_len,field_end_pos)
    # print(sort_list)
    #print(",C',',\n".join(sort_list))
    #print("output-length:", field_len, sum(field_len))
    outrec_str=",C',',\n  ".join(sort_list)
    lrecl=sum(field_len) -1 # Subtracting 1 for comma added to last field
    SRT_JOB_STR="""//SORTJOB JOB
//PREDEL DD DSN=<OFILE>,DSN=(MOD,DEL,DEL)
//STEP01    EXEC PGM=SORT
//SYSOUT    DD SYSOUT=*
//SORTIN    DD DSN=<IFILE>
//SORTOUT   DD DSN=<OFILE>
//       DISP=(NEW,CATLG,DELETE),UNIT=SYSDA,
//       SPACE=(CYL,(1,4),RLSE),
//       DCB=(RECFM=FB,LRECL=<LRECL>,BLKSIZE=0)
//SYSIN     DD *
  SORT FIELDS=COPY
  OUTREC FIELDS=("""
    sort_job_str = SRT_JOB_STR.replace("<LRECL>",str(lrecl)).replace("<IFILE>",input_dsn)\
    .replace("<OFILE>",sort_dsn) + outrec_str + "\n/*\n//"
    return sort_job_str


def gen_sort_outrec(dde, sort_list, field_len,field_end_pos):
    if dde.level == "88":
        return

    if not dde.contains:
        if dde.cumoffset > field_end_pos[-1]:    # logic for ignoring redefine
            start_pos = dde.cumoffset + 1
            start_pos +=len(field_len)
            length = dde.size
            fld_len = 0

            if dde.usage.myName == "COMP-3" or dde.usage.myName == "COMP":
                numeric, size, scale, precision = dde.sizeScalePrecision
                fld_len = size
                bef_decimal = "T" * (size - precision)
                if precision > 0:
                    aft_decimal = "T" * precision
                    edit_str = f"{bef_decimal}.{aft_decimal}"
                    fld_len += 1
                else:
                    edit_str = f"{bef_decimal}"
                if dde.usage.signed:
                    edit_str = "S" + edit_str
                    fld_len += 1

                if dde.usage.myName == "COMP-3":
                    data_type = "PD"
                elif dde.usage.myName == "COMP":
                    data_type = "BI"

                sort_str = f"{start_pos},{length},{data_type},EDIT=({edit_str})"

            if dde.usage.myName in ("DISPLAY"):
                sort_str = f"{start_pos},{length}"
                fld_len = dde.size

            if dde.usage.myName in ("COMP", "COMP-3", "DISPLAY"):
                # print(sort_str)
                sort_list.append(sort_str)
                field_len.append(fld_len + 1)  # Adding one for comma seperator
                field_end_pos.append(dde.cumoffset + dde.size - 1)

    if dde.contains:
        for f in dde.contains:
            gen_sort_outrec(f, sort_list, field_len,field_end_pos)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "-c",
        "--copybook",
        type=str,
        default="",
        help="Specify Copybook file",
        required=True
    )

    parser.add_argument(
        "-i",
        "--input_dsn",
        type=str,
        default="",
        help="Specify input DSN"
    )
    parser.add_argument(
        "-s",
        "--sort_dsn",
        type=str,
        default="",
        help="Specify sort output DSN"
    )
    parser.add_argument(
        "-r",
        "--report_offset",
        action="store_true",
        default=False,
        help="Print offset of copybook vars",
    )
    parser.add_argument(
        "-g",
        "--gen_sort",
        action="store_true",
        help="Generate sort card",
    )
    parser.add_argument(
        "-o",
        "--output_file",
        type=str,
        default="",
        help="Output file where sort job will be written"
    )

    args = parser.parse_args()

    if args.copybook == "":
        parser.print_help()
        exit(4)
    else:
        if not os.path.isfile(args.copybook):
            print("File not present -", args.copybook)
            exit(8)

    copybook_file = args.copybook
    dde = generate_dde(copybook_file)

    if args.report_offset:
        report_offset(dde)
    
    if args.input_dsn != "":
        input_dsn = args.input_dsn
    else:
        input_dsn =None
    
    if args.sort_dsn != "":
        sort_dsn = args.sort_dsn
    else:
        sort_dsn =None

    if args.gen_sort:
        if input_dsn and sort_dsn:
            sort_job_str = generate_sort(dde,input_dsn,sort_dsn)
            if args.output_file:
                with open(args.output_file,"w") as file:
                    file.writelines(sort_job_str)
            else:
                print(sort_job_str)
        else:
            print("Provide input and sort DSN")
            parser.print_help()
            exit(4)
